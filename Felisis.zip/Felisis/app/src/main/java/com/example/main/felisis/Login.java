package com.example.main.felisis;

/**
 * Created by Hasini on 3/29/2017.
 */

public class Login {
    EditText username = (EditText)findViewById(R.id.editText1);
    EditText password = (EditText)findViewById(R.id.editText2);

    //getting the username and password
    public void login(View view){
        if(username.getText().toString().equals("admin") && password.getText().toString().equals("admin")){

            system.out.println("login successfull");
        }else{
            system.out.println("login failed.Try again");

            //avoiding unwanted attempts in login
            int counter = 3;
            counter--;

            if(counter==0){
                Button.setEnabled(false);
            }

        }
    }
